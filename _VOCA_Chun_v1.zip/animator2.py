from utils.commons import configurator
from model import networks
from psbody.mesh import Mesh
from scipy.io import wavfile
from tqdm import tqdm
from moviepy.editor import *
from utils_animator.utils import *
import torch.backends.cudnn as cudnn
import gc
from utils.audio_handler import AudioHandler
import pickle

# from pydub import AudioSegment
# import sounddevice as sd
# import soundfile as sf
# from DeepSpeech.deepspeech_pytorch.model import DeepSpeech
# import matplotlib.pyplot as plt
# from matplotlib.collections import PolyCollection
# from DeepSpeech.utils import parse_audio
# import torch
# import numpy as np
# from tqdm import tqdm
# import io
# import os
# import cv2
# import scipy
# import tempfile
# import numpy as np
# from subprocess import call
# from utils_animator.utils import animator_initialization, vertex2img
# from DeepSpeech.deepspeech import deepspeecher
# from scipy.io import wavfile

np.set_printoptions(threshold=sys.maxsize)

def main():
    # 1 initialization

    ## Basic
    args = configurator.Load_Config().parse_args()
    identity = 2

    ## Template
    template = Mesh(filename='C:/Pycharm Projects/Datasets/VOCASET/template/FLAME_sample.ply')

    ## Option

    ## Output
    foldername = 'practice7'
    video_fname = './output' + str(identity) + str(foldername) +'.mp4'
    video_fname_sound = './output_with_'+str(identity)+'_'+str(foldername)+'_sound2.mp4'

    audio_fname = 'C:/Pycharm Projects/Projects/_VOCA_Chun_v0/data/test_sentence.wav'
    model_path = 'C:/Pycharm Projects/Projects/_VOCA_Chun_v0/saved/LSTM/'+str(foldername)+'/model/model_last.pth'

    ## Inut related
    sample_rate, audio = wavfile.read(audio_fname)
    processed_audio = process_audio('./ds_graph/output_graph.pb', audio, sample_rate)
    out = torch.tensor(processed_audio)
    out = out.permute([0, 2, 1])
    out = out.reshape([out.shape[0], out.shape[1], out.shape[2], 1]).double()

    condition_vector_1 = np.zeros([out.shape[0], 8, 16,1])
    condition_vector_2 = np.zeros([out.shape[0],8, 1,1])
    condition_vector_1[:,identity, :, :] = 1.0
    condition_vector_2[:,identity, :, :] = 1.0
    condition_vector_1 = torch.tensor(condition_vector_1).double()
    condition_vector_2 = torch.tensor(condition_vector_2).double()

    # model Initialization
    model = networks.Model_Establishment(args)
    model.to("cuda")
    cudnn.benchmark = True
    model = torch.nn.DataParallel(model)
    model.to("cuda")
    checkpoint = torch.load(model_path)
    model.load_state_dict(checkpoint['state_dict'])
    model = model.double()
    model.eval()


    with torch.no_grad():

        templates_data = pickle.load(open('C:/Pycharm Projects/Datasets/VOCASET/templates.pkl', 'rb'),
                                          encoding='latin1')
        template.v = template.v.T
        # sequence_vertices, _ = model(out, condition_vector_1, condition_vector_2, torch.tensor(templates_data['FaceTalk_170728_03272_TA']).double().cuda().flatten()) # voca
        sequence_vertices, _ = model(out, condition_vector_1, condition_vector_2, torch.tensor(template.v).double().cuda().flatten()) # flame head (ideal)

        num_frames = sequence_vertices.shape[0]
        sequence_vertices = sequence_vertices.reshape([-1,5023,3]).cpu().numpy()

        fps = 60
        fourcc = cv2.VideoWriter_fourcc(*'DIVX')
        writer = cv2.VideoWriter(video_fname, fourcc, fps, (1080, 1080))

        ##################################
        for i_frame in tqdm(range(num_frames)):

            V, F = sequence_vertices[i_frame], template.f.T

            # question mark
            V = (V - (V.max(0) + V.min(0)) / 2) / max(V.max(0) - V.min(0))
            MVP = perspective(25, 1, 1, 100) @ translate(0, 0, -3.5) @ xrotate(10) @ yrotate(
                30)  # view point tuning parameter?
            V = np.c_[V, np.ones(len(V))] @ MVP.T
            V /= V[:, 3].reshape(-1, 1)
            V = V[F]
            T = V[:, :, :2]
            Z = -V[:, :, 2].mean(axis=1)
            zmin, zmax = Z.min(), Z.max()
            Z = (Z - zmin) / (zmax - zmin)
            C = plt.get_cmap("magma")(Z)
            I = np.argsort(Z)
            T, C = T[I, :], C[I, :]
            fig = plt.figure(figsize=(6, 6))
            ax = fig.add_axes([0, 0, 1, 1], xlim=[-1, +1], ylim=[-1, +1], aspect=1, frameon=False)
            collection = PolyCollection(T, closed=True, linewidth=0.1, facecolor=C, edgecolor="black")
            ax.add_collection(collection)
            img = get_img_from_fig(fig, dpi=180)\

            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            if i_frame == 0:
                for _ in range(int(fps / 7)):
                    writer.write(img)
            writer.write(img)
            plt.close('all')
            gc.collect()

        writer.release()

        videoclip = VideoFileClip(video_fname)
        audioclip = AudioFileClip(audio_fname)

        new_audioclip = CompositeAudioClip([audioclip])
        videoclip.audio = new_audioclip
        videoclip.write_videofile(video_fname_sound)
        os.remove(video_fname)

def process_audio(ds_path, audio, sample_rate):
    config = {}
    config['deepspeech_graph_fname'] = ds_path
    config['audio_feature_type'] = 'deepspeech'
    config['num_audio_features'] = 29

    config['audio_window_size'] = 16
    config['audio_window_stride'] = 1

    tmp_audio = {'subj': {'seq': {'audio': audio, 'sample_rate': sample_rate}}}
    audio_handler = AudioHandler(config)

    return audio_handler.process(tmp_audio)['subj']['seq']['audio']

if __name__ == '__main__':
    main()
