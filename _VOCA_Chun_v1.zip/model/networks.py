#import model
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.backends.cudnn as cudnn
import numpy as np

#######################################################
# succesful place
# input = torch.ones([1, 1, 16, 37])
# conv_bn_lrelu_1 = conv_bn_lrelu(filter_shape=(3,37), input_shape=1,
#                                              num_filters=4,
#                                              strides=2, padding=(1,0), name="conv1")
# a = conv_bn_lrelu_1(input)
# print(torch.permute(a, (0,3, 2, 1)))
#######################################################
def truncated_normal_(tensor, mean=0, std=0.1): # require weight tensor
    size = tensor.shape
    tmp = tensor.new_empty(size + (4,)).normal_()
    valid = (tmp < 2) & (tmp > -2)
    ind = valid.max(-1, keepdim=True)[1]
    tensor.data.copy_(tmp.gather(-1, ind).squeeze(-1))
    tensor.data.mul_(std).add_(mean)
    return tensor

def truncated_normal_2(tensor, mean=0, std=0.1): # require raw tensor
    # sample u1:
    size = tensor.weight.size()
    u1 = torch.rand(size) * (1 - np.exp(-std)) + np.exp(-std)
    # sample u2:
    u2 = torch.rand(size)
    # sample the truncated gaussian ~TN(0,1,[-2,2]):
    z = torch.sqrt(-std * torch.log(u1)) * torch.cos(std * np.pi * u2)
    tensor.weight.data = z

class conv_bn_lrelu(nn.Module):
    def __init__(self, filter_shape, input_shape, num_filters, strides, padding = (1, 0), name = None):
        super().__init__()
        self.conv = nn.Conv2d(input_shape, num_filters, kernel_size=filter_shape, stride=strides,
                              padding=padding, bias=True)  # may need padding
        # self.bn = nn.BatchNorm2d(num_filters, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True,
        #                          device=None, dtype=None)
        #self.lrelu = nn.LeakyReLU(negative_slope=0.1, inplace=False) # 0.01
        self.lrelu = nn.ReLU(True)  # 0.01

        ## Initialization
        nn.init.xavier_normal_(self.conv.weight, gain=0.1)

        #self.conv.weight = truncated_normal_(self.conv.weight)
        #truncated_normal_2(self.conv)


    def forward(self, x):
        x = self.conv(x)
        # x = self.bn(x)
        x = self.lrelu(x)
        return x

class VOCA_model_encoder(nn.Module):
    def __init__(self, args):
        super().__init__()

        self.conv_bn_lrelu_1 = conv_bn_lrelu(filter_shape=(3, 1), input_shape=37,
                                             num_filters=32,
                                             strides=(2, 1), padding=(1, 0), name="conv1")
        self.conv_bn_lrelu_2 = conv_bn_lrelu(filter_shape=(3, 1), input_shape=32,
                                             num_filters=32,
                                             strides=(2, 1), padding=(1, 0), name="conv2")
        self.conv_bn_lrelu_3 = conv_bn_lrelu(filter_shape=(3, 1), input_shape=32,
                                             num_filters=64,
                                             strides=(2, 1), padding=(1, 0), name="conv3")
        self.conv_bn_lrelu_4 = conv_bn_lrelu(filter_shape=(3, 1), input_shape=64,
                                             num_filters=64,
                                             strides=(2, 1), padding=(1, 0), name="conv4")
        # self.conv_bn_lrelu_1 = conv_bn_lrelu(filter_shape=(3, 1), input_shape=37,
        #                                      num_filters=32,
        #                                      strides=(2, 1), padding=(0, 0), name="conv1")
        # self.conv_bn_lrelu_2 = conv_bn_lrelu(filter_shape=(3, 1), input_shape=32,
        #                                      num_filters=32,
        #                                      strides=(2, 1), padding=(0, 0), name="conv2")
        # self.conv_bn_lrelu_3 = conv_bn_lrelu(filter_shape=(3, 1), input_shape=32,
        #                                      num_filters=64,
        #                                      strides=(2, 1), padding=(0, 0), name="conv3")
        # self.conv_bn_lrelu_4 = conv_bn_lrelu(filter_shape=(3, 1), input_shape=64,
        #                                      num_filters=64,
        #                                      strides=(2, 1), padding=(0, 0), name="conv4")


        self.fc1 = nn.Linear(72, 128)
        self.tanh = nn.Tanh()
        self.fc2 = nn.Linear(128, 50)

        ## Initialization
        nn.init.xavier_normal_(self.fc1.weight, gain=0.1)
        nn.init.xavier_normal_(self.fc2.weight, gain=0.1)
        #self.fc1.weight = truncated_normal_(self.fc1.weight)
        #self.fc2.weight = truncated_normal_(self.fc2.weight)
        #truncated_normal_2(self.fc1)
        #truncated_normal_2(self.fc2)


    def forward(self, x, identity_1, identity_2):



        x = torch.cat((x, identity_1), dim=1)
        x = self.conv_bn_lrelu_1(x)

        x = self.conv_bn_lrelu_2(x)

        x = self.conv_bn_lrelu_3(x)

        x = self.conv_bn_lrelu_4(x)


        x = torch.cat((x, identity_2), dim=1)

        x = x.reshape([-1, x.shape[1]])

        x = self.fc1(x)

        x = self.tanh(x)

        x = self.fc2(x)

        return x

class VOCA_model_decoder(nn.Module):
    def __init__(self, args):
        super().__init__()
        #self.drop_rate = args.dropout

        self.fc3 = nn.Linear(50, args.num_vertex)

        self.expression_basis_fname = 'C:/Pycharm Projects/Datasets/VOCASET/init_expression_basis.npy'
        a = torch.tensor(np.load(self.expression_basis_fname)[:,:50])

        self.fc3.weight = torch.nn.Parameter(a)
        #self.fc3.weight = a

        # print(self.fc3.weight)
        # print(a)

    def forward(self, x):
        #x = F.dropout(x, p=self.drop_rate)

        x = self.fc3(x)

        return x
# init_exp_basis[:, :min(self.expression_dim, 100)] = np.load(self.expression_basis_fname)[:, :min(self.expression_dim, 100)]

class VOCA_model(nn.Module):
    def __init__(self, encoder=None, decoder=None):
        super().__init__()
        self.bn = nn.BatchNorm2d(29, eps=1e-05, momentum=0.9, affine=True, track_running_stats=True,
                                 device=None, dtype=None)
        self.encoder = encoder
        self.decoder = decoder

    def forward(self, x, identity_1=None, identity_2=None, facial_template=None):
        # x = torch.cat((x,identity_1),dim=1)
        #print(x.shape)
        x = self.bn(x)

        x = self.encoder(x, identity_1, identity_2)

        enc = x.reshape([-1])
        x = self.decoder(x)

        x = x + facial_template


        return x, enc

# a = VOCA_model(VOCA_model_encoder(args),VOCA_model_decoder(args))
# input = torch.ones([1, 29, 1, 16])
# i1 = torch.ones([1, 8, 1, 16])
# i2 = torch.ones([1, 8, 1, 1])
# #input = torch.cat((input,i1),dim=1)
# # print(input.shape)
# # exit()
#
#
# b = a(input,i1, i2)
#
# exit()


def Model_Establishment(args):
    net = VOCA_model(VOCA_model_encoder(args),VOCA_model_decoder(args))

    # if args.device == 'gpu':
    #     device = torch.device('cuda')
    #     cudnn.benchmark = True
    #     net = torch.nn.DataParallel(net)
    # else:
    #     device = torch.device('cpu')
    #
    # net.to(device)

    return net
