import json
import torch
import pandas as pd
from pathlib import Path
from itertools import repeat
from collections import OrderedDict
import sys
import time
import os
from datetime import datetime
import shutil
import torch.backends.cudnn as cudnn
from utils.commons.logger import get_logger, add_filehandler
from utils.commons.visualization import TensorboardWriter
from pthflops import count_ops
from ptflops import get_model_complexity_info
from torch.cuda.amp import GradScaler
import random
import numpy as np

def ensure_dir(dirname):
    dirname = Path(dirname)
    if not dirname.is_dir():
        dirname.mkdir(parents=True, exist_ok=False)


def read_json(fname):
    fname = Path(fname)
    with fname.open('rt') as handle:
        return json.load(handle, object_hook=OrderedDict)


def write_json(content, fname):
    fname = Path(fname)
    with fname.open('wt') as handle:
        json.dump(content, handle, indent=4, sort_keys=False)


def inf_loop(data_loader):
    ''' wrapper function for endless data loader. '''
    for loader in repeat(data_loader):
        yield from loader


def prepare_device(n_gpu_use):
    """
    setup GPU device if available. get gpu device indices which are used for DataParallel
    """
    n_gpu = torch.cuda.device_count()
    if n_gpu_use > 0 and n_gpu == 0:
        print("Warning: There\'s no GPU available on this machine,"
              "training will be performed on CPU.")
        n_gpu_use = 0
    if n_gpu_use > n_gpu:
        print(f"Warning: The number of GPU\'s configured to use is {n_gpu_use}, but only {n_gpu} are "
              "available on this machine.")
        n_gpu_use = n_gpu
    device = torch.device('cuda:0' if n_gpu_use > 0 else 'cpu')
    list_ids = list(range(n_gpu_use))
    return device, list_ids


class MetricTracker:
    def __init__(self, *keys, writer=None):
        self.writer = writer
        self._data = pd.DataFrame(index=keys, columns=['total', 'counts', 'average'])
        self.reset()

    def reset(self):
        for col in self._data.columns:
            self._data[col].values[:] = 0

    def update(self, key, value, n=1):
        if self.writer is not None:
            self.writer.add_scalar(key, value)
        self._data.total[key] += value * n
        self._data.counts[key] += n
        self._data.average[key] = self._data.total[key] / self._data.counts[key]

    def avg(self, key):
        return self._data.average[key]

    def result(self):
        return dict(self._data.average)


TOTAL_BAR_LENGTH = 60
last_time = time.time()
begin_time = last_time
if sys.platform[:3] == 'win':
    term_width = 1
else:
    _, term_width = os.popen('stty size', 'r').read().split()
term_width = int(term_width)


def progress_bar(current, total, epochs, cur_epoch, msg=None):
    global last_time, begin_time
    if current == 0:
        begin_time = time.time()  # Reset for new bar.

    cur_len = int(TOTAL_BAR_LENGTH * current / total)
    rest_len = int(TOTAL_BAR_LENGTH - cur_len) - 1

    sys.stdout.write(' [')
    for i in range(cur_len):
        sys.stdout.write('=')
    sys.stdout.write('>')
    for i in range(rest_len):
        sys.stdout.write('.')
    sys.stdout.write(']')

    cur_time = time.time()
    step_time = cur_time - last_time
    last_time = cur_time
    tot_time = cur_time - begin_time
    remain_time = step_time * (total - current) + (epochs - cur_epoch) * step_time * total

    L = []
    L.append('  Step: %s' % format_time(step_time))
    L.append(' | Tot: %s' % format_time(tot_time))
    L.append(' | Rem: %s' % format_time(remain_time))
    if msg:
        L.append(' | ' + msg + ' |')

    msg = ''.join(L)
    sys.stdout.write(msg)
    for i in range(term_width - int(TOTAL_BAR_LENGTH) - len(msg) - 3):
        sys.stdout.write(' ')

    # Go back to the center of the bar.
    for i in range(term_width - int(TOTAL_BAR_LENGTH / 2) + 2):
        sys.stdout.write('\b')
    sys.stdout.write(' %d/%d ' % (current + 1, total))

    if current < total - 1:
        sys.stdout.write('\r')
    else:
        sys.stdout.write('\n')
    sys.stdout.flush()


def format_time(seconds):
    days = int(seconds / 3600 / 24)
    seconds = seconds - days * 3600 * 24
    hours = int(seconds / 3600)
    seconds = seconds - hours * 3600
    minutes = int(seconds / 60)
    seconds = seconds - minutes * 60
    secondsf = int(seconds)
    seconds = seconds - secondsf
    millis = int(seconds * 1000)

    f = ''
    i = 1
    if days > 0:
        f += str(days) + 'D'
        i += 1
    if hours > 0 and i <= 2:
        f += str(hours) + 'h'
        i += 1
    if minutes > 0 and i <= 2:
        f += str(minutes).zfill(2) + 'm'
        i += 1
    if secondsf > 0 and i <= 2:
        f += str(secondsf).zfill(2) + 's'
        i += 1
    if millis > 0 and i <= 2:
        f += str(millis).zfill(3) + 'ms'
        i += 1
    if f == '':
        f = '0ms'
    return f


class Best_Performance():

    def __init__(self, name=''):
        self.name = ''
        self.value = 0.0

    def update(self, value):
        self.value = value

    def return_value(self):
        return self.value


def Validity_Check(path, args):
    #assert args.resume['activation'] == os.path.exists(path['log_path']), 'check resume option (logging)'
    assert args.resume['activation'] == os.path.exists(
        path['model_path'] + '/' + args.resume['check_point']), 'check resume option (model)'



def Initialization(args):

    # random seed init
    seed = args.seed
    torch.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)

    current_time = str(datetime.now())[:-7].replace(':', '_')

    # Directory Init
    path = {
        'log_path':os.path.join(args.directory['save_dir'],
                            *['saved', args.directory['folder_name'], args.directory['instance_name'], 'log']),
        'model_path':os.path.join(args.directory['save_dir'],
                              *['saved', args.directory['folder_name'], args.directory['instance_name'], 'model'])
            }
    Validity_Check(path, args)  # validity check
    os.makedirs(path['log_path'], exist_ok=True), os.makedirs(path['model_path'], exist_ok=True)  # create directory

    # Logger
    logger = get_logger('Default_Logger')  # log init
    add_filehandler(logger, os.path.join(path['log_path'], 'log.txt'))
    shutil.copyfile(args.config, os.path.join(path['log_path'], 'config ' + current_time + '.yaml'))

    #TB-Writer
    TBwriter = {
        'train' : TensorboardWriter(path['log_path'] + '/train', logger, args.UseTB_train),
        'val' : TensorboardWriter(path['log_path'] + '/val', logger, args.UseTB_val)
    }

    # HW Device Setting
    if args.device == 'cpu':
        pass
    elif args.device == 'gpu' or args.device == 'cuda':
        assert torch.cuda.is_available(), 'cuda may not be available'
        args.device = 'cuda'

    # worker setting
    if args.workers == 'free':
        args.workers = 4 * int((len(os.environ["CUDA_VISIBLE_DEVICES"]) + 1) / 2)

    # Print Initialization Result
    logger.info('\n\n\nStart Logging')
    logger.info('############### Initialization ###############\n')  ####################
    logger.info('########## Current Configuration\n')
    for i in vars(args):
        logger.info(i + ' : ' + str(vars(args)[i]))
    logger.info('########## Done\n\n')

    return logger, TBwriter, path


def Finalization(model, optimizer, path, logger, args, data_shape):
    logger.info('########## Finalization')
    epoch = 1
    best_perf = Best_Performance(args.metrics['critical_metric'])

    scaler = GradScaler()

    if args.device == 'gpu' or args.device == 'cuda':
        cudnn.benchmark = True
        model = torch.nn.DataParallel(model)
    else:
        # device = torch.device('cpu')
        pass

    model.to(args.device)

    if args.resume['activation']:
        # checkpoint = torch.load(path['model_path'] + '/model_last.pth')
        checkpoint = torch.load(path['model_path'] + '/' + args.resume['check_point'])
        model.load_state_dict(checkpoint['state_dict'])
        optimizer.load_state_dict(checkpoint['optimizer'])
        epoch = checkpoint['epoch']
        logger.info("Loading Epoch: {} ...".format(epoch))
        epoch += 1
        best_perf.update(checkpoint['monitor_best'])
        logger.info("Loading best performance: {} ...".format(best_perf.return_value()))



    # if args.device == 'gpu' or args.device == 'cuda':
    #     cudnn.benchmark = True
    #     model = torch.nn.DataParallel(model)
    # else:
    #     device = torch.device('cpu')



    # args.workers = number of GPU*4

    # inp = torch.rand(1,1,224,224).to(device)
    # count_ops(net,inp)
    # logger.info('Network Property: ')
    # print(data_shape)
    # macs, params = get_model_complexity_info(model, data_shape, as_strings=True,
    #                                          print_per_layer_stat=False, verbose=True)
    # logger.info('{:<30}  {:<8}'.format('Computational complexity: ', macs))
    # logger.info('{:<30}  {:<8}'.format('Number of parameters: ', params))
    # logger.info('########## Done\n')

    return model, optimizer, epoch, best_perf, scaler, args
