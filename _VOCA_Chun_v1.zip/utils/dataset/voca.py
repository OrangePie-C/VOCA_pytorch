from PIL import Image
import os
import os.path
import numpy as np
import csv
import pickle
import random
import torch
from pathlib import Path
import pickle
from torch import Tensor
from typing import List, Dict, Union, Any, Callable, Optional, Tuple
from torch.utils.data import Dataset
import torchaudio
from visualizer import visualize3D
from utils_animator.utils import vertex2img
from psbody.mesh import Mesh

index_reference = {
    'FaceTalk_170725_00137_TA': [0, 10367],
    'FaceTalk_170731_00024_TA': [10368, 20152],
    'FaceTalk_170904_00128_TA': [20153, 31398],
    'FaceTalk_170809_00138_TA': [31399, 39811],
    'FaceTalk_170915_00223_TA': [39812, 50467],
    'FaceTalk_170728_03272_TA': [50468, 57898],
    'FaceTalk_170811_03274_TA': [57899, 70150],
    'FaceTalk_170811_03275_TA': [70151, 79869],
    'FaceTalk_170904_03276_TA': [79870, 91878],
    'FaceTalk_170908_03277_TA': [91879, 102238],
    'FaceTalk_170912_03278_TA': [102239, 112397],
    'FaceTalk_170913_03279_TA': [112398, 123340],
}


def load_commonvoice_item(line: List[str],
                          header: List[str],
                          path: str,
                          folder_audio: str,
                          ext_audio: str) -> Tuple[Tensor, int, Dict[str, str]]:
    # Each line as the following data:
    # client_id, path, sentence, up_votes, down_votes, age, gender, accent

    assert header[1] == "path"
    fileid = line[1]
    filename = os.path.join(path, folder_audio, fileid)
    if not filename.endswith(ext_audio):
        filename += ext_audio
    waveform, sample_rate = torchaudio.load(filename)

    dic = dict(zip(header, line))

    return waveform, sample_rate, dic


counter = 0


class VOCASET(Dataset):

    def __init__(self, args=None, mode=None):

        self.args = args
        self.path = self.args.directory['data_dir']  # os.fspath(root)
        self.mode = mode
        self.datashape = [16, 29]
        self.targetshape = 15069  # [5023, 3]

        # define split configuration
        # self.sequence = self.args.data['sentences']
        if self.mode == 'train':
            self.subject = self.args.data['train']
        elif self.mode == 'val':
            self.subject = self.args.data['validation']

        # data Loading
        if self.args.data['use_voca_processed_audio']:
            print("using original voca default deepspeech processed audio")
            self.audio = pickle.load(open(os.path.join(self.path, 'processed_audio_deepspeech.pkl'), 'rb'),
                                     encoding='latin1')
        else:
            exit("mi gu hyun")
        self.face_vert = np.load(os.path.join(self.path, 'data_verts.npy'), mmap_mode='r')  # face vertices (target)
        # self.raw_audio = pickle.load(open(os.path.join(self.path,'raw_audio_fixed.pkl'), 'rb'), encoding='latin1')
        self.indexer = pickle.load(open(os.path.join(self.path, 'subj_seq_to_idx.pkl'), 'rb'), encoding='latin1')

        self.templates_data = pickle.load(open('C:/Pycharm Projects/Datasets/VOCASET/templates.pkl', 'rb'), encoding='latin1')
        # # data Spliting
        # for i in range(len(self.templates_data)):
        #     print(i+1)
        #     v = self.templates_data[list(self.templates_data.keys())[i]]
        #     visualize3D(v)
        #
        # print("Check")
        # print(self.templates_data['FaceTalk_170725_00137_TA'])
        # print(self.templates_data['FaceTalk_170725_00137_TA'].shape)
        #
        # print(self.face_vert.shape)
        # print(self.face_vert[0])
        # print(self.face_vert[0].shape)
        # for i in range(10367+1):
        #     print(((self.templates_data['FaceTalk_170725_00137_TA'] - self.face_vert[i])**2).sum())
        # #print(self.)
        # exit()

        for i in self.args.data['sum']:
            if i not in self.subject:
                #self.templates_data.pop(i, None)  # input
                self.audio.pop(i, None)  # input
                self.indexer.pop(i, None)

        # audio = []
        # for _ in range(self.face_ver): audio.append([])
        # print(self.face_vert.shape[0])
        audio = [[] for _ in range(self.face_vert.shape[0])]
        indexer = []

        for i in self.indexer:
            # print('i '+i)
            for j in self.indexer[i]:
                if j not in self.audio[i].keys():
                    # print(j)
                    # print("exemption!!   :  " + str(j))
                    # print(len(list(self.indexer[i][j].values())))
                    continue

                indexer.extend(list(self.indexer[i][j].values()))
                for k in self.indexer[i][j]:


                    audio[self.indexer[i][j][k]] = self.audio[i][j]['audio'][k]

        self.indexer_list, self.audio = indexer, audio  #
        del indexer, audio

    def extract_neighboring_v2(self, n, index, facename):
        for i in self.indexer[facename].keys():
            try:
                localframe = list(self.indexer[facename][i].keys())[list(self.indexer[facename][i].values()).index(index)]
                sentence = i
                break
            except:
                continue

        try:
            neighbor_index = self.indexer[facename][sentence][localframe-1]
            flag = 'prev'
        except:
            neighbor_index = self.indexer[facename][sentence][localframe + 1]
            flag = 'later'
        neighbor_input = self.audio[neighbor_index]
        neighbor_target = self.face_vert[neighbor_index].reshape([-1])  # 5023 x 3 to turn back!

        return neighbor_input, neighbor_target, flag




    def extract_neighboring(self, n, index):

        if abs(self.indexer_list[n] - self.indexer_list[n - 1]) > 1:
            neighbor_input = self.audio[self.indexer_list[n + 1]]
            neighbor_target = self.face_vert[self.indexer_list[n + 1]].reshape([-1])
            flag = 'later' # sub
            # counter += 1
            # print("None neighboring detected! : " + str(counter))

        elif abs(self.indexer_list[n] - self.indexer_list[n - 1]) == 1:
            flag = 'prev' # main
            neighbor_input = self.audio[self.indexer_list[n - 1]]
            neighbor_target = self.face_vert[self.indexer_list[n - 1]].reshape([-1])
        else:
            exit("error in extracting neighboring data")

        return neighbor_input, neighbor_target, flag

    def extract_condition_data(self, index):
        identity = -1
        condition_vector_1 = np.zeros([16, len(self.args.data['train'])])
        condition_vector_2 = np.zeros([1, len(self.args.data['train'])])
        if self.mode == 'train':
            for i in list(index_reference.keys()): # face name
                range_list = index_reference[i]
                if index <= max(range_list) and index >= min(range_list):
                    identity = self.args.data['train'].index(i)
                    facename = i # currently selected face name
                    break
                else:
                    pass
            if identity == -1:
                exit("Error")
            facial_template = self.templates_data[facename]
            condition_vector_1[:, identity] = 1
            condition_vector_2[:, identity] = 1

        if self.mode == 'val':
            for i in list(index_reference.keys()):
                range_list = index_reference[i]
                if index <= max(range_list) and index >= min(range_list):
                    #identity = self.args.data['train'].index(i)
                    identity = self.args.data['validation'].index(i)

                    facename = i
                    break
                else:
                    pass
            if identity == -1:
                exit("Error")
            identity = -1 # random.randint(0, len(self.args.data['train']) - 1)

            # condition_vector_1[:, identity] = 1
            # condition_vector_2[:, identity] = 1
            facial_template = self.templates_data[facename]

            #facial_template = self.templates_data[facename]

        return condition_vector_1, condition_vector_2, facename, facial_template, identity #facial_template.reshape([-1])

    def __getitem__(self, n: int) -> Tuple[Tensor, int, Dict[str, str]]:

        # initial data extraction
        index = self.indexer_list[n]
        input_data = self.audio[index]
        target_data = self.face_vert[index].reshape([-1]) # 5023 x 3 to turn back!

        # advanced data extraction
        condition_data_1, condition_data_2, facename, facial_template, identity = self.extract_condition_data(index)

        neighbor_input, neighbor_target, flag = self.extract_neighboring_v2(n, index, facename) # 이거 다시 짜야됨.

        # consecutivity reflection
        if flag == 'later':
            input_data = np.concatenate((input_data, neighbor_input), axis=0).reshape(
                [2, self.datashape[0], self.datashape[1]]).transpose(0, 2, 1)
            target_data = np.concatenate((target_data, neighbor_target), axis=0).reshape([2, self.targetshape])
        elif flag == 'prev': # main
            input_data = np.concatenate((neighbor_input, input_data), axis=0).reshape(
                [2, self.datashape[0], self.datashape[1]]).transpose(0, 2, 1)
            target_data = np.concatenate((neighbor_target, target_data), axis=0).reshape([2, self.targetshape])


        condition_data_1 = np.concatenate((condition_data_1, condition_data_1), axis=0).reshape(
            [2, 16, len(self.args.data['train'])]).transpose(0, 2, 1)
        condition_data_2 = np.concatenate((condition_data_2, condition_data_2), axis=0).reshape(
            [2, 1, len(self.args.data['train'])]).transpose(0, 2, 1)

        facial_template = np.concatenate((facial_template, facial_template), axis=0).reshape(
            [2, -1])

        input_data = torch.from_numpy(input_data)
        target_data = torch.from_numpy(target_data)
        condition_data_1 = torch.from_numpy(condition_data_1)
        condition_data_2 = torch.from_numpy(condition_data_2)


        ################################################

        #
        # template = Mesh(filename='C:/Pycharm Projects/Datasets/VOCASET/template/FLAME_sample.ply')
        #
        # print()
        # print(facename)
        # print(identity)
        # print()
        # for i in range(2):
        #     vertex2img(target_data[i].numpy().reshape([-1,3]),template.f.T)
        #     vertex2img(facial_template[i].reshape([-1,3]),template.f.T)

        return input_data, target_data, condition_data_1, condition_data_2, facial_template
        # return input_data, target_data

    def __len__(self) -> int:
        return len(self.indexer_list)
