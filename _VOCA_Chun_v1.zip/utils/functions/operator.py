import torch
from abc import abstractmethod
from numpy import inf
from utils.commons import TensorboardWriter
from utils.commons import progress_bar
from torch.cuda.amp import GradScaler, autocast
# from tqdm import tqdm
import time
from visualizer import visualize3D
import pickle
import os
from utils_animator.utils import vertex2img
from psbody.mesh import Mesh
import numpy as np
import sys
np.set_printoptions(threshold=sys.maxsize)
eps = 0.0001


def _resume_checkpoint(self, resume_path):
    """
    Resume from saved checkpoints

    :param resume_path: Checkpoint path to be resumed
    """
    resume_path = str(resume_path)
    self.logger.info("Loading checkpoint: {} ...".format(resume_path))
    checkpoint = torch.load(resume_path)
    self.start_epoch = checkpoint['epoch'] + 1
    self.mnt_best = checkpoint['monitor_best']

    # load architecture params from checkpoint.
    if checkpoint['config']['arch'] != self.config['arch']:
        self.logger.warning("Warning: Architecture configuration given in config file is different from that of "
                            "checkpoint. This may yield an exception while state_dict is being loaded.")
    self.model.load_state_dict(checkpoint['state_dict'])

    # load optimizer state from checkpoint only when optimizer type is not changed.
    if checkpoint['config']['optimizer']['type'] != self.config['optimizer']['type']:
        self.logger.warning("Warning: Optimizer type given in config file is different from that of checkpoint. "
                            "Optimizer parameters not being resumed.")
    else:
        self.optimizer.load_state_dict(checkpoint['optimizer'])

    self.logger.info("Checkpoint loaded. Resume training from epoch {}".format(self.start_epoch))


def save_checkpoint(model, optimizer, epoch, logger, model_path, cur_perf, best_perf, args):
    """
    Saving checkpoints

    :param epoch: current epoch number
    :param log: logging information of the epoch
    :param save_best: if True, rename the saved checkpoint to 'model_best.pth'
    """

    state = {
        'epoch': epoch,
        'state_dict': model.state_dict(),
        'optimizer': optimizer.state_dict(),
        'monitor_best': best_perf.return_value(),
        'args': args
    }
    filename = str(model_path['model_path'] + '/checkpoint-epoch{}.pth'.format(epoch))
    torch.save(state, filename)
    # logger.info("Saving checkpoint: {} ...".format(filename))
    filename = str(model_path['model_path'] + '/model_last.pth')
    torch.save(state, filename)

    # Save best
    if cur_perf <= best_perf.return_value():
        best_perf.update(cur_perf)

        best_path = str(model_path['model_path'] + '/model_best.pth')
        torch.save(state, best_path)
        logger.info("Best Performance Found! : {}".format(best_perf.return_value()))

        # print('Current Instance: ' + args.directory['instance_name'])

    # # Save best
    if cur_perf >= best_perf.return_value():
        best_perf.update(cur_perf)
        best_path = str(model_path['model_path'] + '/model_best.pth')
        torch.save(state, best_path)
        logger.info("Best Performance Found! : {}".format(best_perf.return_value()))


######################################################################################
def train_epoch(train_loader, model, optimizer, scheduler,  # Basic
                loss_functions, metric_functions, meter, logger, best_perf,  # Performance
                epoch, results_dict, model_path, scaler, criterion_1, criterion_2, args):  # ETC
    model.train()
    scheduler.step(epoch)  # Scheduler

    #template = Mesh(filename='C:/Pycharm Projects/Datasets/VOCASET/template/FLAME_sample.ply')

    for batch_idx, (data, target, condition_1, condition_2, facial_template) in enumerate(train_loader):

        # data processing
        data = data.reshape([-1, data.shape[2], data.shape[3]]).double()
        data = data.reshape([data.shape[0], data.shape[1], data.shape[2], 1]).double()

        target = target.reshape([-1, target.shape[2]]).double() # .half()
        facial_template = facial_template.reshape([-1, facial_template.shape[2]]).double()  # .half()

        condition_1 = condition_1.reshape([-1, condition_1.shape[2], condition_1.shape[3], 1]).double() # .half()
        condition_2 = condition_2.reshape([-1, condition_2.shape[2], condition_2.shape[3], 1]).double() # .half()

        data, target, condition_1, condition_2, facial_template = data.to(args.device), target.to(
            args.device), condition_1.to(args.device), condition_2.to(args.device), facial_template.to(
            args.device)  # B x H x W
        num_samples = data.shape[0] / 2

        optimizer.zero_grad()

        start = time.time()
        #zero_face = torch.zeros_like(facial_template)
        output, _ = model(data, condition_1, condition_2, facial_template)
        end = time.time()

        loss_1 = criterion_1(output, target)
        meter.update(loss_functions[0].__name__, loss_1.item(), n=num_samples)
        #loss_1.backward(retain_graph=True)

        loss_2 = criterion_2(output, target)
        meter.update(loss_functions[1].__name__, loss_2.item(), n=num_samples)
        #loss_2.backward(retain_graph=True)

        loss_int = loss_1 + loss_2
        loss_int.backward()

        optimizer.step()

        ###############################################################################

        # Record Metrics
        for m_func in metric_functions:
            # meter.update(m_func.__name__, 1/(m_func(output, target)+eps), n = num_samples)
            meter.update(m_func.__name__, m_func(output, target), n=num_samples)

        # Record ETC
        meter.update('time of each sample', end - start, n=num_samples)

        progress_bar(batch_idx, len(train_loader), args.epochs, epoch,
                     (str(args.metrics['critical_metric'] + ' : ' + str(meter.result()[
                                                                            args.metrics['critical_metric']]))))
    logger.info('training loss: ' + str(meter.result()[args.metrics['critical_metric']]))
    meter.step_setting(epoch)


def validate_epoch(val_loader, model, optimizer, scheduler,  # Basic
                   loss_functions, metric_functions, meter, logger, best_perf,  # Performance
                   epoch, results_dict, model_path, scaler, args):  # ETC
    model.eval()

    with torch.no_grad():

        training_facial = pickle.load(open('C:/Pycharm Projects/Datasets/VOCASET/templates.pkl', 'rb'),
                                          encoding='latin1')  # template

        for batch_idx, (data, target, condition_1, condition_2, facial_template) in enumerate(val_loader):

            # data = data.reshape([-1, data.shape[2],data.shape[3]])
            # target = target.reshape([-1,target.shape[2]])
            # condition_1 = condition_1.reshape([-1, condition_1.shape[2], condition_1.shape[3]])
            # condition_2 = condition_2.reshape([-1, condition_2.shape[2], condition_2.shape[3]])

            data = data.reshape([-1, data.shape[2], data.shape[3], 1]).double() # .float()  # .half()
            target = target.reshape([-1, target.shape[2]]).double()  # .half()
            condition_1 = condition_1.reshape([-1, condition_1.shape[2], condition_1.shape[3], 1]).double() #.float()  # .half()
            condition_2 = condition_2.reshape([-1, condition_2.shape[2], condition_2.shape[3], 1]).double()# float()  # .half()
            facial_template = facial_template.reshape([-1, facial_template.shape[2]]).double() # 이 친구는 진짜 얼굴

            data, target, condition_1, condition_2, facial_template = data.to(args.device), target.to(args.device), condition_1.to(
                args.device), condition_2.to(args.device), facial_template.to(args.device)  # B x H x W
            num_samples = data.shape[0] / 2

            target_disp = target - facial_template
            target_disp = target_disp.to(args.device)

            for i in range(8):

                c_facial = torch.tensor(training_facial[args.data['train'][i]]).to(args.device).reshape([-1]) # or .flatten()

                target = target_disp + c_facial

                condition_1[:,:,:,:] = 0
                condition_2[:,:,:,:] = 0

                condition_1[:,i,:,:] = 1
                condition_2[:,i,:,:] = 1

                start = time.time()
                output, _ = model(data, condition_1, condition_2, c_facial)
                end = time.time()

                # Record Meters
                for l_func in loss_functions:
                    loss = l_func(args)(output, target)
                    meter.update(l_func.__name__, loss.item(), n=num_samples)

                # Record Metrics
                for m_func in metric_functions:
                    # meter.update(m_func.__name__, 1/(m_func(output, target)+eps), n=num_samples)
                    meter.update(m_func.__name__, m_func(output, target), n=num_samples)

                # Record ETC
                meter.update('time of each sample', end - start, n=num_samples)

            progress_bar(batch_idx, len(val_loader), args.epochs, epoch,
                         (str(args.metrics['critical_metric'] + ' : ' + str(meter.result()[
                                                                                args.metrics[
                                                                                    'critical_metric']]))))

        logger.info('validation loss: ' + str(meter.result()[args.metrics['critical_metric']]))
        cur_perf = meter.result()[args.metrics['critical_metric']]  # standard metric
        save_checkpoint(model, optimizer, epoch, logger, model_path, cur_perf, best_perf, args)
