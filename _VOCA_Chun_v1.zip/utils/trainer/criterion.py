import pdb

import torch
import torch.nn as nn

import torch.nn.functional as F
from torch.autograd import Variable


# class SiLogLoss(nn.Module):
#     def __init__(self, lambd=0.5):
#         super().__init__()
#         self.lambd = lambd
#
#     def forward(self, pred, target):
#         valid_mask = (target > 0).detach()
#         diff_log = torch.log(target[valid_mask]) - torch.log(pred[valid_mask])
#         loss = torch.sqrt(torch.pow(diff_log, 2).mean() - self.lambd * torch.pow(diff_log.mean(), 2))
#
#         return loss
#
#
#
#
#
# class CrossEntropyLoss(nn.Module):
#     def __init__(self, ignore_index=255):
#         super().__init__()
#         self.criterion = nn.CrossEntropyLoss(ignore_index=ignore_index)
#
#     def forward(self, pred, target):
#         loss = self.criterion(pred, target)
#
#         return loss




# class MSELoss(nn.Module):
#     def __init__(self, args=None):
#         super().__init__()
#         self.args = args
#         self.criterion = nn.MSELoss()
#
#     def forward(self, pred, target):
#         # pred = pred.double()
#         # target = target.double()
#
#         loss = self.criterion(pred, target)
#         return loss

class MSELoss(nn.Module):
    def __init__(self, args=None):
        super().__init__()
        self.args = args
        self.criterion = nn.MSELoss()

    def forward(self, pred, target):
        # pred = pred.double()
        # target = target.double()
        #num_samples = pred.shape[0]

        # loss = (((pred - target) ** 2).sum()) / (num_samples * 5023 * 3)
        loss = self.criterion(pred,target)
        #loss = ((pred - target) ** 2).mean()#.reshape([num_samples,-1,3])
        #loss = (sqrd.sum(dim=2)).mean() # / (num_samples * 5023) # * 3)

        return loss


class Velocity_loss(nn.Module):
    def __init__(self, args=None):
        super().__init__()
        self.args = args
        self.L2_loss = MSELoss(self.args)

    def forward(self, pred, target):

        # pred = pred.double()
        # target = target.double()

        num_samples = int(target.shape[0]/2)
        loss = torch.tensor(0.0).cuda().double()
        for i in range(num_samples):
            vel_pred = pred[2 * i] - pred[2 * i + 1]
            vel_target = target[2 * i] - target[2 * i + 1]
            #loss += self.L2_loss(vel_pred,vel_target).sum()

            sqrd = ((vel_pred - vel_target)**2).reshape([-1,3])
            loss += (sqrd.sum(dim=1)).mean()
            #loss += (((vel_pred - vel_target)**2).sum())
            # loss += self.L2_loss(vel_pred, vel_target).sum()
        loss = loss * self.args.velocity_weight #.mean() # / (num_samples*5023*3)
        return loss


def criterion_establishment(args) -> object:
    criterion_dict = {}
    criterion_dict['loss_name_1'] = CrossEntropyLoss()  # variable()
    criterion_dict['loss_name_2'] = MSELoss()  # variable()
    return criterion_dict


