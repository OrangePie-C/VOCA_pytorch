import torch
import pandas as pd
from torch import nn

def accuracy(output, target):
    with torch.no_grad():
        pred = torch.argmax(output, dim=1)
        assert pred.shape[0] == len(target)
        correct = 0
        correct += torch.sum(pred == target).item()
    return correct / len(target)


def top_k_acc(output, target, k=5):
    with torch.no_grad():
        pred = torch.topk(output, k, dim=1)[1]
        assert pred.shape[0] == len(target)
        correct = 0
        for i in range(k):
            correct += torch.sum(pred[:, i] == target).item()
    return correct / len(target)

def MSELoss_perf(pred, target):
    #target = target.float()
    loss = nn.MSELoss()(pred, target).double().item()
    return loss

class MetricTracker():
    """Computes and stores the average and current value"""

    def __init__(self, keys, results_dict, writer=None):
        self.result_dict = results_dict
        self.writer = writer
        self._data = pd.DataFrame(index=keys, columns=['total', 'counts', 'average'])
        self.reset()


    def reset(self):
        for col in self._data.columns:
            self._data[col].values[:] = 0

    def step_setting(self, epoch):
        self.writer.set_step((epoch - 1), '')

    def update(self, key, value, n=1):
        self._data.total[key] += value * n
        self._data.counts[key] += n
        self._data.average[key] = round(self._data.total[key] / self._data.counts[key], 10)

    def avg(self, key):
        return self._data.average[key]

    def result(self):
        return dict(self._data.average)

    def write_scalar_TB(self):
        temp_result = self.result()
        for i in temp_result:
            self.writer.add_scalar(i, temp_result[i])

    def write_scalars_TB(self):
        temp_result = self.result()

        for i in self.result_dict:
            for j in range(len(self.result_dict[i])):
                self.writer.add_scalar(i + '/' + self.result_dict[i][j], temp_result[self.result_dict[i][j]])
    def write_network(self, model,args, data_shape):
        self.writer.add_graph(model.to(args.device), torch.rand(1, data_shape[0], data_shape[1], data_shape[2]).to(args.device))



