
import torch.optim as optim


def Optimizer_Establishment(model, args):

    if args.optimizer['type'] == 'SGD':
        optimizer = optim.SGD(model.parameters(), lr = args.optimizer['learning_rate'], momentum=args.optimizer['momentum'], dampening=0,
                 weight_decay=args.optimizer['decay'], nesterov=True)
    if args.optimizer['type'] == 'Adagrad':
        optimizer = optim.Adagrad(model.parameters(), lr = args.optimizer['learning_rate'], lr_decay=0,
                                  weight_decay=args.optimizer['decay'], initial_accumulator_value=0, eps=1e-10)
    elif args.optimizer['type'] == 'Adam':
        optimizer = optim.Adam(model.parameters(), lr = args.optimizer['learning_rate'],
                               betas= (0.9, 0.999), eps= 1e-8, weight_decay= args.optimizer['decay'], amsgrad = False)
    elif args.optimizer['type'] == 'NAdam':
        optimizer = optim.NAdam(model.parameters(), lr=args.optimizer['learning_rate'],
                               betas=(0.9, 0.999), eps=1e-8, weight_decay=args.optimizer['decay'], momentum_decay=4e-3)
    elif args.optimizer['type'] == 'RMSprop':
        optimizer = optim.RMSprop(model.parameters(), lr=args.optimizer['learning_rate'],
                                alpha = 0.99, eps = 1e-8, weight_decay = args.optimizer['decay'], momentum = 0, centered = False)
    # elif type == '':

    else:
        exit("Optimizer Error!!")

    #optimizer = getattr(optim, args.optimizer)(model.parameters(), lr=args.lr)

    return optimizer