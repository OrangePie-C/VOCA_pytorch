
import torch

def Scheduler_Establishment(optimizer, args):
    #model = globals()[model_name.capitalize()]()

    if args.scheduler['type'] == 'None':
        scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer=optimizer,
                                                  lr_lambda=lambda epoch: 1.0 ** epoch)
    elif args.scheduler['type'] == 'LambdaLR':
        scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer=optimizer, lr_lambda=lambda epoch: args.scheduler['lambda'] ** epoch)
    elif args.scheduler['type'] == 'ExponentialLR':
        scheduler = torch.optim.lr_scheduler.ExponentialLR(optimizer, gamma=args.scheduler['gamma'])
    elif args.scheduler['type'] == 'CosineAnnealing':
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs, eta_min=args.optimizer['learning_rate']*0.01)

    elif args.scheduler['type'] == 'StepLR':
        scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=args.scheduler['step_size'], gamma=args.scheduler['gamma'])
    elif args.scheduler['type'] == 'MultiStepLR':
        scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=args.scheduler['milestone'], gamma=args.scheduler['gamma'])
    # elif args.scheduler['type'] == '':

    else:
        exit("scheduler error!!")

    return scheduler
