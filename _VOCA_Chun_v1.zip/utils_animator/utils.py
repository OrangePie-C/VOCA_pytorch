import os
from datetime import datetime
from utils.commons.logger import get_logger, add_filehandler
from python_speech_features import mfcc
import numpy as np
import resampy
import io
import cv2
import torch
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection
import gc

def getiton(spect):
    def func(p):
        return p[0].size(1)

    batch = sorted(spect, key=lambda sample: sample[0].size(1), reverse=True)
    longest_sample = max(batch, key=func)[0]
    freq_size = longest_sample.size(0)
    minibatch_size = len(batch)
    max_seqlength = longest_sample.size(1)
    inputs = torch.zeros(1, 1, freq_size, max_seqlength)
    input_percentages = torch.FloatTensor(minibatch_size)
    for x in range(minibatch_size):
        sample = batch[x]
        tensor = sample[0]
        seq_length = tensor.size(1)
        inputs[x][0].narrow(1, 0, seq_length).copy_(tensor)
        input_percentages[x] = seq_length / float(max_seqlength)

    return inputs, input_percentages

def animator_initialization(args):

    os.makedirs(args.path['obj_output'], exist_ok=True)
    os.makedirs(args.path['video_output'], exist_ok=True)  # create directory

def frustum(left, right, bottom, top, znear, zfar):
    M = np.zeros((4, 4), dtype=np.float32)
    M[0, 0] = +2.0 * znear / (right - left)
    M[1, 1] = +2.0 * znear / (top - bottom)
    M[2, 2] = -(zfar + znear) / (zfar - znear)
    M[0, 2] = (right + left) / (right - left)
    M[2, 1] = (top + bottom) / (top - bottom)
    M[2, 3] = -2.0 * znear * zfar / (zfar - znear)
    M[3, 2] = -1.0
    return M

def perspective(fovy, aspect, znear, zfar):
    h = np.tan(0.5*np.radians(fovy)) * znear
    w = h * aspect
    return frustum(-w, w, -h, h, znear, zfar)

def translate(x, y, z):
    return np.array([[1, 0, 0, x], [0, 1, 0, y],
                     [0, 0, 1, z], [0, 0, 0, 1]], dtype=float)

def xrotate(theta):
    t = np.pi * theta / 180
    c, s = np.cos(t), np.sin(t)
    return np.array([[1, 0,  0, 0], [0, c, -s, 0],
                     [0, s,  c, 0], [0, 0,  0, 1]], dtype=float)

def yrotate(theta):
    t = np.pi * theta / 180
    c, s = np.cos(t), np.sin(t)
    return  np.array([[ c, 0, s, 0], [ 0, 1, 0, 0],
                      [-s, 0, c, 0], [ 0, 0, 0, 1]], dtype=float)

def get_img_from_fig(fig, dpi=180):
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=dpi)
    buf.seek(0)
    img_arr = np.frombuffer(buf.getvalue(), dtype=np.uint8)
    buf.close()
    img = cv2.imdecode(img_arr, 1)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    return img

def vertex2img(V,F):


    # question mark
    V = (V - (V.max(0) + V.min(0)) / 2) / max(V.max(0) - V.min(0))
    MVP = perspective(25, 1, 1, 100) @ translate(0, 0, -3.5) @ xrotate(10) @ yrotate(
        30)  # view point tuning parameter?
    V = np.c_[V, np.ones(len(V))] @ MVP.T
    V /= V[:, 3].reshape(-1, 1)
    V = V[F]
    T = V[:, :, :2]
    Z = -V[:, :, 2].mean(axis=1)
    zmin, zmax = Z.min(), Z.max()
    Z = (Z - zmin) / (zmax - zmin)
    C = plt.get_cmap("magma")(Z)
    I = np.argsort(Z)
    T, C = T[I, :], C[I, :]
    fig = plt.figure(figsize=(6, 6))
    ax = fig.add_axes([0, 0, 1, 1], xlim=[-1, +1], ylim=[-1, +1], aspect=1, frameon=False)
    collection = PolyCollection(T, closed=True, linewidth=0.1, facecolor=C, edgecolor="black")
    ax.add_collection(collection)
    plt.show()
    img = get_img_from_fig(fig, dpi=180)

    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    plt.close('all')
    gc.collect()


    return img


# def audioToInputVector(audio, fs, numcep, numcontext):
#
#
#     resampled_audio = resampy.resample(audio.astype(float), sample_rate, 16000)
#     # Get mfcc coefficients
#     features = mfcc(audio, samplerate=fs, numcep=numcep)
#
#     # We only keep every second feature (BiRNN stride = 2)
#     features = features[::2]
#
#     # One stride per time step in the input
#     num_strides = len(features)
#
#     # Add empty initial and final contexts
#     empty_context = np.zeros((numcontext, numcep), dtype=features.dtype)
#     features = np.concatenate((empty_context, features, empty_context))
#
#     # Create a view into the array with overlapping strides of size
#     # numcontext (past) + 1 (present) + numcontext (future)
#     window_size = 2 * numcontext + 1
#     train_inputs = np.lib.stride_tricks.as_strided(
#         features,
#         (num_strides, window_size, numcep),
#         (features.strides[0], features.strides[0], features.strides[1]),
#         writeable=False)
#
#     # Flatten the second and third dimensions
#     train_inputs = np.reshape(train_inputs, [num_strides, -1])
#
#     train_inputs = np.copy(train_inputs)
#     train_inputs = (train_inputs - np.mean(train_inputs)) / np.std(train_inputs)
#
#     # Return results
#     return train_inputs

