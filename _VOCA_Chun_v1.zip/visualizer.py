
import numpy as np
from matplotlib import pyplot as plt
from utils_animator.utils import *
from matplotlib.collections import PolyCollection
from psbody.mesh import Mesh

a = Mesh(filename='C:/Pycharm Projects/Datasets/VOCASET/template/FLAME_sample.ply')


def visualize3D(vertex,face=a.f):

    #V = vertex.cpu().numpy().reshape([-1,3])
    V = vertex
    F = face.T

    # V, F = sequence_vertices[i_frame], template.f

    # question mark
    V = (V - (V.max(0) + V.min(0)) / 2) / max(V.max(0) - V.min(0))
    MVP = perspective(25, 1, 1, 100) @ translate(0, 0, -3.5) @ xrotate(10) @ yrotate(
        30)  # view point tuning parameter?
    V = np.c_[V, np.ones(len(V))] @ MVP.T
    V /= V[:, 3].reshape(-1, 1)
    V = V[F]
    T = V[:, :, :2]
    Z = -V[:, :, 2].mean(axis=1)
    zmin, zmax = Z.min(), Z.max()
    Z = (Z - zmin) / (zmax - zmin)
    C = plt.get_cmap("magma")(Z)
    I = np.argsort(Z)
    T, C = T[I, :], C[I, :]
    fig = plt.figure(figsize=(6, 6))
    ax = fig.add_axes([0, 0, 1, 1], xlim=[-1, +1], ylim=[-1, +1], aspect=1, frameon=False)
    collection = PolyCollection(T, closed=True, linewidth=0.1, facecolor=C, edgecolor="black")
    ax.add_collection(collection)
    #img = get_img_from_fig(fig, dpi=180)
    plt.show()
